# app/parsers/generic.py
from __future__ import annotations
from .base import BaseFeedParser

class GenericParser(BaseFeedParser):
    """대부분의 일반 RSS/Atom에 적용되는 기본 파서."""
    pass
