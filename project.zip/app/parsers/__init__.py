# app/parsers/__init__.py
from .registry import get_parser
__all__ = ["get_parser"]
